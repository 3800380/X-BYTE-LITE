const _0x4bee7f = function () {
    const _0x4487af = {
      HrfzA: function (_0x4412a0, _0x458573) {
        return _0x4412a0 !== _0x458573;
      }
    };
    _0x4487af.viiNY = "BbbDL";
    _0x4487af.LoKFv = function (_0xb0b3ab, _0x211dfa) {
      return _0xb0b3ab === _0x211dfa;
    };
    _0x4487af.gHRPx = "EPFRK";
    _0x4487af.wBcUS = "while (true) {}";
    _0x4487af.SMrYd = "counter";
    _0x4487af.UkSHk = "ljueF";
    let _0x3b34af = true;
    return function (_0x3e4ed2, _0x6fe3e6) {
      const _0x172aaf = {
        'ZSrEB': function (_0xb97da5, _0x503a40) {
          return _0xb97da5 !== _0x503a40;
        },
        'EUxLr': _0x4487af.viiNY,
        'xLhtx': function (_0x27ee9c, _0x1976ec) {
          return _0x4487af.LoKFv(_0x27ee9c, _0x1976ec);
        },
        'zcZMR': _0x4487af.gHRPx,
        'IufmO': _0x4487af.wBcUS,
        'jMULP': _0x4487af.SMrYd
      };
      if (_0x4487af.LoKFv(_0x4487af.UkSHk, _0x4487af.UkSHk)) {
        const _0x4946ca = _0x3b34af ? function () {
          if (_0x172aaf.EUxLr !== _0x172aaf.EUxLr) {
            const _0x4d115 = _0x4f7817 ? function () {
              if (_0x4d6fa5) {
                const _0x303e38 = _0xfe71d.apply(_0x5b1682, arguments);
                _0x4fed1d = null;
                return _0x303e38;
              }
            } : function () {};
            _0x5d95ac = false;
            return _0x4d115;
          } else {
            if (_0x6fe3e6) {
              if (_0x4487af.LoKFv(_0x172aaf.zcZMR, _0x172aaf.zcZMR)) {
                const _0x20f61b = _0x6fe3e6.apply(_0x3e4ed2, arguments);
                _0x6fe3e6 = null;
                return _0x20f61b;
              } else {
                const _0x311f71 = _0x4bd187.apply(_0x2f357f, arguments);
                _0x5e4ebe = null;
                return _0x311f71;
              }
            }
          }
        } : function () {};
        _0x3b34af = false;
        return _0x4946ca;
      } else {
        return function (_0x417aa8) {}.constructor(_0x172aaf.IufmO).apply(_0x172aaf.jMULP);
      }
    };
  }();
  const _0x1224e6 = _0x4bee7f(this, function () {
    return _0x1224e6.toString().search("(((.+)+)+)+$").toString().constructor(_0x1224e6).search("(((.+)+)+)+$");
  });
  _0x1224e6();
  const _0x16068e = function () {
    let _0x1449c3 = true;
    return function (_0x1ed991, _0x26c9b6) {
      const _0x528fed = _0x1449c3 ? function () {
        if (_0x26c9b6) {
          const _0x1cf292 = _0x26c9b6.apply(_0x1ed991, arguments);
          _0x26c9b6 = null;
          return _0x1cf292;
        }
      } : function () {};
      _0x1449c3 = false;
      return _0x528fed;
    };
  }();
  (function () {
    _0x16068e(this, function () {
      const _0x1e171c = new RegExp("function *\\( *\\)");
      const _0x51abba = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
      const _0x527746 = _0x15ffe9("init");
      if (!_0x1e171c.test(_0x527746 + "chain") || !_0x51abba.test(_0x527746 + "input")) {
        _0x527746('0');
      } else {
        _0x15ffe9();
      }
    })();
  })();
  const _0x289ce6 = function () {
    const _0x53cf11 = {
      FAkpd: function (_0x3203e5, _0x179cc7) {
        return _0x3203e5 !== _0x179cc7;
      },
      LKPtm: "QpClN",
      mSaBI: "xfctm",
      Gmnqh: "VlOtO",
      NfFhr: "oLIXP",
      zyJQO: function (_0x35c436, _0x4daf9a) {
        return _0x35c436 === _0x4daf9a;
      }
    };
    _0x53cf11.NBFxf = "PbsGE";
    _0x53cf11.XuRQM = "wFNuV";
    let _0x24b0cd = true;
    return function (_0x3305c9, _0x48612a) {
      if (_0x53cf11.NBFxf === _0x53cf11.XuRQM) {
        return false;
      } else {
        const _0x5f06c9 = _0x24b0cd ? function () {
          if (_0x48612a) {
            const _0x5727bf = _0x48612a.apply(_0x3305c9, arguments);
            _0x48612a = null;
            return _0x5727bf;
          }
        } : function () {};
        _0x24b0cd = false;
        return _0x5f06c9;
      }
    };
  }();
  const _0x22c3c7 = _0x289ce6(this, function () {
    const _0x5ceb78 = function () {
      let _0x2b8f5b;
      try {
        _0x2b8f5b = Function("return (function() {}.constructor(\"return this\")( ));")();
      } catch (_0x1c7a59) {
        _0x2b8f5b = window;
      }
      return _0x2b8f5b;
    };
    const _0x345d54 = _0x5ceb78();
    const _0x5d06d1 = _0x345d54.console = _0x345d54.console || {};
    const _0x3620b9 = ["log", "warn", "info", "error", "exception", "table", "trace"];
    for (let _0x121abf = 0; _0x121abf < _0x3620b9.length; _0x121abf++) {
      const _0x292093 = _0x289ce6.constructor.prototype.bind(_0x289ce6);
      const _0x2595ca = _0x3620b9[_0x121abf];
      const _0x33a0c4 = _0x5d06d1[_0x2595ca] || _0x292093;
      _0x292093.__proto__ = _0x289ce6.bind(_0x289ce6);
      _0x292093.toString = _0x33a0c4.toString.bind(_0x33a0c4);
      _0x5d06d1[_0x2595ca] = _0x292093;
    }
  });
  _0x22c3c7();
  import _0x39be65 from 'yt-search';
  import _0x1753da from 'node-fetch';
  import _0x58024c, { prepareWAMessageMedia } from '@whiskeysockets/baileys';
  const {
    generateWAMessageFromContent,
    proto
  } = _0x58024c;
  const videoMap = new Map();
  let videoIndex = 1;
  let audioIndex = 1001;
  const song = async (_0x1cb216, _0x54ff10) => {
    let _0x2b7aba;
    const _0x17754a = _0x1cb216?.["message"]?.["templateButtonReplyMessage"]?.["selectedId"];
    const _0x18d87c = _0x1cb216?.["message"]?.["interactiveResponseMessage"];
    if (_0x18d87c) {
      const _0x4547a6 = _0x18d87c.nativeFlowResponseMessage?.["paramsJson"];
      if (_0x4547a6) {
        const _0x5055ce = JSON.parse(_0x4547a6);
        _0x2b7aba = _0x5055ce.id;
      }
    }
    const _0x347756 = _0x2b7aba || _0x17754a;
    const _0x36d27e = _0x1cb216.body.match(/^[\\/!#.]/);
    const _0x49b305 = _0x36d27e ? _0x36d27e[0] : '/';
    const _0x266f6e = _0x1cb216.body.startsWith(_0x49b305) ? _0x1cb216.body.slice(_0x49b305.length).split(" ")[0].toLowerCase() : '';
    const _0x3ce637 = _0x1cb216.body.slice(_0x49b305.length + _0x266f6e.length).trim();
    const _0x74ac69 = ["yts", "ytsearch"];
    if (_0x74ac69.includes(_0x266f6e)) {
      if (!_0x3ce637) {
        return _0x1cb216.reply("Please provide a YouTube URL or search query");
      }
      try {
        await _0x1cb216.React('🕘');
        const _0x387ed2 = await _0x39be65(_0x3ce637);
        const _0x24b25f = _0x387ed2.videos.slice(0, 10);
        if (_0x24b25f.length === 0) {
          _0x1cb216.reply("No results found.");
          await _0x1cb216.React('❌');
          return;
        }
        const _0x95cdfb = _0x24b25f.map((_0x5ac68e, _0x3c3086) => {
          const _0x5ee656 = videoIndex + _0x3c3086;
          const _0x39ebee = {
            ..._0x5ac68e
          };
          _0x39ebee.isAudio = false;
          videoMap.set(_0x5ee656, _0x39ebee);
          const _0x4f1d81 = {
            header: '',
            title: _0x5ac68e.title,
            description: '',
            id: "video_" + _0x5ee656
          };
          return _0x4f1d81;
        });
        const _0x16b6e1 = _0x24b25f.map((_0x589c17, _0x4e137d) => {
          const _0x111e0b = audioIndex + _0x4e137d;
          const _0x5cccef = {
            ..._0x589c17
          };
          _0x5cccef.isAudio = true;
          videoMap.set(_0x111e0b, _0x5cccef);
          const _0x4ce714 = {
            header: '',
            title: _0x589c17.title,
            description: '',
            id: "audio_" + _0x111e0b
          };
          return _0x4ce714;
        });
        const _0x8b7530 = _0x24b25f[0];
        const _0x2613bc = {
          title: _0x8b7530.title,
          author: _0x8b7530.author.name,
          duration: _0x8b7530.timestamp,
          views: _0x8b7530.views,
          url: "https://www.youtube.com/watch?v=" + _0x8b7530.videoId,
          thumbnail: _0x8b7530.thumbnail
        };
        const _0x384c50 = {
          deviceListMetadata: {},
          deviceListMetadataVersion: 0x2
        };
        const _0x1dc958 = {
          text: "*X-BYTE-LITE VIDEO DOWNLOADER*\n\n> *TITLE:* _" + _0x2613bc.title + "_\n> *AUTHOR:* _" + _0x2613bc.author + "_\n> *DURATION:* _" + _0x2613bc.duration + "_\n> *VIEWS:* _" + _0x2613bc.views + "_\n> *URL:* _" + _0x2613bc.url + '_'
        };
        const _0x20f54f = {
          url: _0x2613bc.thumbnail
        };
        const _0x58bef5 = {
          image: _0x20f54f
        };
        const _0x5e2aa2 = {
          upload: _0x54ff10.waUploadToServer
        };
        const _0x5f519c = generateWAMessageFromContent(_0x1cb216.from, {
          'viewOnceMessage': {
            'message': {
              'messageContextInfo': _0x384c50,
              'interactiveMessage': proto.Message.InteractiveMessage.create({
                'body': proto.Message.InteractiveMessage.Body.create(_0x1dc958),
                'footer': proto.Message.InteractiveMessage.Footer.create({
                  'text': "© Powered By X-BYTE-LITE"
                }),
                'header': proto.Message.InteractiveMessage.Header.create({
                  ...(await prepareWAMessageMedia(_0x58bef5, _0x5e2aa2)),
                  'title': '',
                  'gifPlayback': true,
                  'subtitle': '',
                  'hasMediaAttachment': false
                }),
                'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  'buttons': [{
                    'name': "single_select",
                    'buttonParamsJson': JSON.stringify({
                      'title': "SELECT A VIDEO",
                      'sections': [{
                        'title': "Top 10 YouTube Results - Videos",
                        'highlight_label': "Top 10",
                        'rows': _0x95cdfb
                      }]
                    })
                  }, {
                    'name': "single_select",
                    'buttonParamsJson': JSON.stringify({
                      'title': " SELECT AN AUDIO",
                      'sections': [{
                        'title': "Top 10 YouTube Results - Audios",
                        'highlight_label': "Top 10",
                        'rows': _0x16b6e1
                      }]
                    })
                  }]
                }),
                'contextInfo': {
                  'mentionedJid': [_0x1cb216.sender],
                  'forwardingScore': 0x270f,
                  'isForwarded': true
                }
              })
            }
          }
        }, {});
        await _0x54ff10.relayMessage(_0x5f519c.key.remoteJid, _0x5f519c.message, {
          'messageId': _0x5f519c.key.id
        });
        await _0x1cb216.React('✅');
        videoIndex += _0x24b25f.length;
        audioIndex += _0x24b25f.length;
      } catch (_0x10c7ff) {
        console.error("Error processing your request:", _0x10c7ff);
        _0x1cb216.reply("Error processing your request.");
        await _0x1cb216.React('❌');
      }
    } else {
      if (_0x347756) {
        const _0x45e1e8 = _0x347756.startsWith("audio_");
        const _0x46f44c = parseInt(_0x347756.replace(_0x45e1e8 ? "audio_" : "video_", ''));
        const _0x4115ba = videoMap.get(_0x46f44c);
        if (_0x4115ba) {
          try {
            const _0x2ffede = "https://www.youtube.com/watch?v=" + _0x4115ba.videoId;
            let _0x32353a;
            if (_0x45e1e8) {
              _0x32353a = "https://api.neoxr.eu/api/youtube?url=" + encodeURIComponent(_0x2ffede) + "&type=audio&quality=128kbps&apikey=ralph";
            } else {
              _0x32353a = "https://matrix-serverless-api.vercel.app/api/ytdl?url=" + encodeURIComponent(_0x2ffede) + "&type=video";
            }
            const _0x4a33e3 = await _0x1753da(_0x32353a);
            const _0x3910df = await _0x4a33e3.json();
            if (_0x4a33e3.ok) {
              const _0x56f525 = _0x45e1e8 ? _0x3910df.data.url : _0x3910df.videoURL;
              const _0x4c2634 = await _0x1753da(_0x56f525).then(_0x33f32a => _0x33f32a.buffer());
              if (_0x45e1e8) {
                const _0x36de1c = {
                  audio: _0x4c2634,
                  mimetype: "audio/mpeg",
                  ptt: false,
                  fileName: _0x4115ba.title + ".mp3",
                  contextInfo: {}
                };
                _0x36de1c.contextInfo.mentionedJid = [_0x1cb216.sender];
                _0x36de1c.contextInfo.externalAdReply = {};
                _0x36de1c.contextInfo.externalAdReply.title = "↺ |◁   II   ▷|   ♡";
                _0x36de1c.contextInfo.externalAdReply.body = "Now playing: " + _0x4115ba.title;
                _0x36de1c.contextInfo.externalAdReply.thumbnailUrl = _0x4115ba.thumbnail;
                _0x36de1c.contextInfo.externalAdReply.sourceUrl = _0x2ffede;
                _0x36de1c.contextInfo.externalAdReply.mediaType = 0x1;
                _0x36de1c.contextInfo.externalAdReply.renderLargerThumbnail = true;
                await _0x54ff10.sendMessage(_0x1cb216.from, _0x36de1c, {
                  'quoted': _0x1cb216
                });
              } else {
                const _0x333490 = {
                  video: _0x4c2634,
                  mimetype: "video/mp4",
                  caption: "> *TITLE:* " + _0x4115ba.title + "\n> *AUTHOR:* " + _0x4115ba.author.name + "\n> *DURATION:* " + _0x4115ba.timestamp + "\n\n> *POWERED BY X-BYTE-LITE*"
                };
                await _0x54ff10.sendMessage(_0x1cb216.from, _0x333490, {
                  'quoted': _0x1cb216
                });
              }
            } else {
              _0x1cb216.reply("Error fetching media.");
              await _0x1cb216.React('❌');
            }
          } catch (_0x2dcc43) {
            console.error("Error fetching video details:", _0x2dcc43);
            _0x1cb216.reply("Error fetching video details.");
            await _0x1cb216.React('❌');
          }
        }
      }
    }
  };
  (function () {
    const _0x231199 = function () {
      let _0x10d0f3;
      try {
        _0x10d0f3 = Function("return (function() {}.constructor(\"return this\")( ));")();
      } catch (_0x881762) {
        _0x10d0f3 = window;
      }
      return _0x10d0f3;
    };
    const _0x54b7cb = _0x231199();
    _0x54b7cb.setInterval(_0x15ffe9, 4000);
  })();
  export default song;
  function _0x15ffe9(_0x518da2) {
    function _0x27b750(_0x301933) {
      if (typeof _0x301933 === "string") {
        return function (_0x175aa2) {}.constructor("while (true) {}").apply("counter");
      } else if (('' + _0x301933 / _0x301933).length !== 1 || _0x301933 % 20 === 0) {
        (function () {
          return true;
        }).constructor("debugger").call("action");
      } else {
        (function () {
          return false;
        }).constructor("debugger").apply("stateObject");
      }
      _0x27b750(++_0x301933);
    }
    try {
      if (_0x518da2) {
        return _0x27b750;
      } else {
        _0x27b750(0);
      }
    } catch (_0x2252b1) {}
  }