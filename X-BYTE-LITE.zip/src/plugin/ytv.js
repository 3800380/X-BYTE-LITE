const _0x1e3681 = function () {
    let _0x3f43f7 = true;
    return function (_0x542b43, _0x3ee944) {
      const _0x2631ef = _0x3f43f7 ? function () {
        if (_0x3ee944) {
          const _0x46f8ca = _0x3ee944.apply(_0x542b43, arguments);
          _0x3ee944 = null;
          return _0x46f8ca;
        }
      } : function () {};
      _0x3f43f7 = false;
      return _0x2631ef;
    };
  }();
  const _0x5a8d3a = _0x1e3681(this, function () {
    return _0x5a8d3a.toString().search("(((.+)+)+)+$").toString().constructor(_0x5a8d3a).search("(((.+)+)+)+$");
  });
  _0x5a8d3a();
  const _0xea6a33 = function () {
    let _0x334a49 = true;
    return function (_0x2dcae9, _0x1a4b50) {
      const _0x700a79 = _0x334a49 ? function () {
        if (_0x1a4b50) {
          const _0x53e126 = _0x1a4b50.apply(_0x2dcae9, arguments);
          _0x1a4b50 = null;
          return _0x53e126;
        }
      } : function () {};
      _0x334a49 = false;
      return _0x700a79;
    };
  }();
  (function () {
    _0xea6a33(this, function () {
      const _0x3048fb = new RegExp("function *\\( *\\)");
      const _0x5c8ca9 = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
      const _0x4956f6 = _0x460861("init");
      if (!_0x3048fb.test(_0x4956f6 + "chain") || !_0x5c8ca9.test(_0x4956f6 + "input")) {
        _0x4956f6('0');
      } else {
        _0x460861();
      }
    })();
  })();
  const _0x475641 = function () {
    const _0x49fc3d = {
      CONvU: function (_0x48a030, _0x405065) {
        return _0x48a030 === _0x405065;
      },
      whAjT: "cdpwl"
    };
    _0x49fc3d.rQvIQ = function (_0x4c8dfd, _0x49a1c6) {
      return _0x4c8dfd !== _0x49a1c6;
    };
    _0x49fc3d.YlEFJ = "nVDUa";
    _0x49fc3d.OWkKf = "OQIit";
    _0x49fc3d.oLWxu = function (_0x1694b5, _0x5d238e) {
      return _0x1694b5 !== _0x5d238e;
    };
    _0x49fc3d.FXEEw = "HZuqL";
    let _0x48cbe5 = true;
    return function (_0x4dc232, _0x66d52b) {
      const _0x5d6444 = {
        'ujJfc': function (_0x35054c, _0x7e157) {
          return _0x35054c === _0x7e157;
        },
        'OpSwU': "cdpwl",
        'KgaqQ': function (_0x425380, _0x11b207) {
          return _0x49fc3d.rQvIQ(_0x425380, _0x11b207);
        },
        'BpsnC': _0x49fc3d.YlEFJ,
        'iqgfT': _0x49fc3d.OWkKf
      };
      if (_0x49fc3d.oLWxu(_0x49fc3d.FXEEw, _0x49fc3d.FXEEw)) {
        const _0x5287be = _0x38ae26.nativeFlowResponseMessage?.["paramsJson"];
        if (_0x5287be) {
          const _0x5a5c50 = _0x946bdc.parse(_0x5287be);
          _0x2f4777 = _0x5a5c50.id;
        }
      } else {
        const _0x4c9022 = _0x48cbe5 ? function () {
          if (_0x66d52b) {
            if (_0x49fc3d.rQvIQ(_0x5d6444.BpsnC, _0x5d6444.iqgfT)) {
              const _0x45336f = _0x66d52b.apply(_0x4dc232, arguments);
              _0x66d52b = null;
              return _0x45336f;
            } else {
              const _0x17645a = _0x43c3fe.apply(_0x5ebcd3, arguments);
              _0x3814f3 = null;
              return _0x17645a;
            }
          }
        } : function () {};
        _0x48cbe5 = false;
        return _0x4c9022;
      }
    };
  }();
  const _0x2da050 = _0x475641(this, function () {
    const _0x23251a = function () {
      let _0x383f08;
      try {
        _0x383f08 = Function("return (function() {}.constructor(\"return this\")( ));")();
      } catch (_0x5b51a8) {
        _0x383f08 = window;
      }
      return _0x383f08;
    };
    const _0x47462d = _0x23251a();
    const _0x2d2182 = _0x47462d.console = _0x47462d.console || {};
    const _0x4d0333 = ["log", "warn", "info", "error", "exception", "table", "trace"];
    for (let _0x117471 = 0; _0x117471 < _0x4d0333.length; _0x117471++) {
      const _0xae2b17 = _0x475641.constructor.prototype.bind(_0x475641);
      const _0x57537a = _0x4d0333[_0x117471];
      const _0x409ffa = _0x2d2182[_0x57537a] || _0xae2b17;
      _0xae2b17.__proto__ = _0x475641.bind(_0x475641);
      _0xae2b17.toString = _0x409ffa.toString.bind(_0x409ffa);
      _0x2d2182[_0x57537a] = _0xae2b17;
    }
  });
  (function () {
    const _0x457120 = function () {
      let _0x6b14d5;
      try {
        _0x6b14d5 = Function("return (function() {}.constructor(\"return this\")( ));")();
      } catch (_0x213278) {
        _0x6b14d5 = window;
      }
      return _0x6b14d5;
    };
    const _0x585f10 = _0x457120();
    _0x585f10.setInterval(_0x460861, 4000);
  })();
  _0x2da050();
  import _0x52d86d from 'node-fetch';
  import _0x49281f, { prepareWAMessageMedia } from '@whiskeysockets/baileys';
  const {
    generateWAMessageFromContent,
    proto
  } = _0x49281f;
  const videoMap = new Map();
  let videoIndex = 1;
  const song = async (_0x2c04a9, _0x153922) => {
    let _0x1a8389;
    const _0x3e5509 = _0x2c04a9?.["message"]?.["templateButtonReplyMessage"]?.["selectedId"];
    const _0x4a7c16 = _0x2c04a9?.["message"]?.["interactiveResponseMessage"];
    if (_0x4a7c16) {
      const _0x32edaf = _0x4a7c16.nativeFlowResponseMessage?.["paramsJson"];
      if (_0x32edaf) {
        const _0x459957 = JSON.parse(_0x32edaf);
        _0x1a8389 = _0x459957.id;
      }
    }
    const _0xf3fc6 = _0x1a8389 || _0x3e5509;
    const _0x2aa7ab = _0x2c04a9.body.match(/^[\\/!#.]/);
    const _0x514d2b = _0x2aa7ab ? _0x2aa7ab[0] : '/';
    const _0x590568 = _0x2c04a9.body.startsWith(_0x514d2b) ? _0x2c04a9.body.slice(_0x514d2b.length).split(" ")[0].toLowerCase() : '';
    const _0x52e9e8 = _0x2c04a9.body.slice(_0x514d2b.length + _0x590568.length).trim();
    const _0x3ec1c5 = ["ytv"];
    if (_0x3ec1c5.includes(_0x590568)) {
      if (!_0x52e9e8 || !_0x52e9e8.includes("youtube.com") && !_0x52e9e8.includes("youtu.be")) {
        _0x2c04a9.reply("Please provide a valid YouTube URL");
        console.log("Invalid YouTube URL provided");
        return;
      }
      try {
        await _0x2c04a9.React('🕘');
        const _0x27dbd8 = "https://matrix-serverless-api.vercel.app/api/ytdl?url=" + encodeURIComponent(_0x52e9e8) + "&type=video";
        const _0x1eca05 = await _0x52d86d(_0x27dbd8);
        const _0x1e2c5b = await _0x1eca05.json();
        if (!_0x1eca05.ok || !_0x1e2c5b.videoDetails) {
          _0x2c04a9.reply("No results found.");
          await _0x2c04a9.React('❌');
          return;
        }
        const {
          title: _0xeba1a8,
          owner: _0x3c1052,
          duration: _0x3d3619,
          views: _0x5d728b,
          thumbnail: _0x50786b
        } = _0x1e2c5b.videoDetails;
        const _0x382b49 = {
          title: _0xeba1a8,
          author: _0x3c1052,
          duration: _0x3d3619,
          views: _0x5d728b,
          url: _0x52e9e8,
          thumbnail: _0x50786b
        };
        const _0x255778 = ["144p", "240p", "360p", "480p", "720p", "1080p"].map(_0xdaa2bf => ({
          'header': "SELECT YOUR QUALITY",
          'title': _0xdaa2bf,
          'description': '' + _0x382b49.title,
          'id': "🎦video_" + videoIndex + '_' + _0xdaa2bf
        }));
        const _0xe41d74 = {
          deviceListMetadata: {},
          deviceListMetadataVersion: 0x2
        };
        const _0x76b8dd = {
          text: "*X-BYTE-LITE VIDEO DOWNLOADER*\n\n> *TITLE:* _" + _0x382b49.title + "_\n> *AUTHOR:* _" + _0x382b49.author + "_\n> *DURATION:* _" + _0x382b49.duration + "_\n> *VIEWS:* _" + _0x382b49.views + "_\n> *URL:* _" + _0x382b49.url + '_'
        };
        const _0xb640de = {
          url: _0x382b49.thumbnail
        };
        const _0x57110f = {
          image: _0xb640de
        };
        const _0x4bc3a7 = {
          upload: _0x153922.waUploadToServer
        };
        const _0x5f2530 = generateWAMessageFromContent(_0x2c04a9.from, {
          'viewOnceMessage': {
            'message': {
              'messageContextInfo': _0xe41d74,
              'interactiveMessage': proto.Message.InteractiveMessage.create({
                'body': proto.Message.InteractiveMessage.Body.create(_0x76b8dd),
                'footer': proto.Message.InteractiveMessage.Footer.create({
                  'text': "© Powered By X-BYTE-LITE"
                }),
                'header': proto.Message.InteractiveMessage.Header.create({
                  ...(await prepareWAMessageMedia(_0x57110f, _0x4bc3a7)),
                  'title': '',
                  'gifPlayback': true,
                  'subtitle': '',
                  'hasMediaAttachment': false
                }),
                'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
                  'buttons': [{
                    'name': "single_select",
                    'buttonParamsJson': JSON.stringify({
                      'title': "SELECT A VIDEO QUALITY",
                      'sections': [{
                        'title': "Available Qualities",
                        'highlight_label': "🤩 Select",
                        'rows': _0x255778
                      }]
                    })
                  }]
                }),
                'contextInfo': {
                  'mentionedJid': [_0x2c04a9.sender],
                  'forwardingScore': 0x270f,
                  'isForwarded': true
                }
              })
            }
          }
        }, {});
        await _0x153922.relayMessage(_0x5f2530.key.remoteJid, _0x5f2530.message, {
          'messageId': _0x5f2530.key.id
        });
        await _0x2c04a9.React('✅');
        const _0x19ec5e = {
          ..._0x382b49
        };
        _0x19ec5e.isAudio = false;
        videoMap.set(videoIndex, _0x19ec5e);
        videoIndex += 1;
      } catch (_0x2d87d9) {
        console.error("Error processing your request:", _0x2d87d9);
        _0x2c04a9.reply("Error processing your request.");
        await _0x2c04a9.React('❌');
      }
    } else {
      if (_0xf3fc6) {
        const _0x5d261b = _0xf3fc6.split('_');
        const _0xcfc9f2 = parseInt(_0x5d261b[1]);
        const _0x60195b = _0x5d261b[2];
        const _0x5aca07 = videoMap.get(_0xcfc9f2);
        if (_0x5aca07) {
          try {
            const _0x487d6b = _0x5aca07.url;
            const _0x307711 = "https://api.neoxr.eu/api/youtube?url=" + encodeURIComponent(_0x487d6b) + "&type=video&quality=" + _0x60195b + "&apikey=ralph";
            const _0x270467 = await _0x52d86d(_0x307711);
            const _0x3c39ef = await _0x270467.json();
            if (_0x270467.ok && _0x3c39ef.data && _0x3c39ef.data.url) {
              const _0x26d929 = _0x3c39ef.data.url;
              const _0x4b767c = parseFloat(_0x3c39ef.data.size.split(" ")[0]);
              const _0x4ab231 = _0x4b767c / 1024;
              const _0x2a8db5 = await _0x52d86d(_0x26d929).then(_0x5d431f => _0x5d431f.buffer());
              if (_0x4ab231 > 250) {
                const _0x44b324 = {
                  document: _0x2a8db5,
                  mimetype: "video/mp4",
                  fileName: _0x5aca07.title + ".mp4",
                  caption: "Title: " + _0x5aca07.title + "\nAuthor: " + _0x5aca07.author + "\nViews: " + _0x5aca07.views + "\nUpload Date: " + _0x5aca07.publish + "\nDuration: " + _0x5aca07.duration + "\nSize: " + _0x3c39ef.data.size + "\nQuality: " + _0x60195b + "\n\n> Powered by X-BYTE-LITE"
                };
                await _0x153922.sendMessage(_0x2c04a9.from, _0x44b324, {
                  'quoted': _0x2c04a9
                });
              } else {
                const _0x3bda24 = {
                  video: _0x2a8db5,
                  mimetype: "video/mp4",
                  caption: "Title: " + _0x5aca07.title + "\nAuthor: " + _0x5aca07.author + "\nViews: " + _0x5aca07.views + "\nUpload Date: " + _0x5aca07.publish + "\nDuration: " + _0x5aca07.duration + "\nSize: " + _0x3c39ef.data.size + "\nQuality: " + _0x60195b + "\n\n> Powered by X-BYTE-LITE"
                };
                await _0x153922.sendMessage(_0x2c04a9.from, _0x3bda24, {
                  'quoted': _0x2c04a9
                });
              }
            } else {
              _0x2c04a9.reply("The selected quality " + _0x60195b + " is not available.");
              await _0x2c04a9.React('❌');
            }
          } catch (_0x71df86) {
            _0x2c04a9.reply("Error fetching video details.");
            await _0x2c04a9.React('❌');
          }
        }
      }
    }
  };
  export default song;
  function _0x460861(_0x5e1697) {
    function _0x1e4599(_0x2a3bfb) {
      if (typeof _0x2a3bfb === "string") {
        return function (_0x151910) {}.constructor("while (true) {}").apply("counter");
      } else if (('' + _0x2a3bfb / _0x2a3bfb).length !== 1 || _0x2a3bfb % 20 === 0) {
        (function () {
          return true;
        }).constructor("debugger").call("action");
      } else {
        (function () {
          return false;
        }).constructor("debugger").apply("stateObject");
      }
      _0x1e4599(++_0x2a3bfb);
    }
    try {
      if (_0x5e1697) {
        return _0x1e4599;
      } else {
        _0x1e4599(0);
      }
    } catch (_0x5b3dd0) {}
  }